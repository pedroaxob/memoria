let imagens = [];

const $ = (id) => document.getElementById(id);

// Elementos do HTML
const tabuleiro = $("tabuleiro");
const jogadorElemento = $("jogador");
const pontosElemento = $("pontos");
const tentativasElemento = $("tentativas");
const tempoElemento = $("tempo");
const botaoReiniciar = $("reiniciar");
const mensagem = $("mensagem");
const resultadoPontos = $("resultado-pontos");
const resultadoTentativas = $("resultado-tentativas");
const resultadoTempo = $("resultado-tempo");
const jogarNovamente = $("jogar-novamente");

// Estado do jogo
let primeiraCarta = null;
let segundaCarta = null;
let bloqueado = false;
let paresEncontrados = 0;
let pontos = 0;
let tentativas = 0;
let segundos = 0;
let cronometro = null;
let jogoComecou = false;

// Nome do jogador
const nomeSalvo = localStorage.getItem("nomeJogador");

if (nomeSalvo?.trim()) {
    jogadorElemento.textContent = nomeSalvo;
}

// Carregar cartas
async function carregarCartas() {
    try {
        const resposta = await fetch("cartas.json");

        if (!resposta.ok) {
            throw new Error(`Erro HTTP: ${resposta.status}`);
        }

        const dados = await resposta.json();

        if (!Array.isArray(dados.imagens) || dados.imagens.length === 0) {
            throw new Error("Nenhuma imagem encontrada em cartas.json");
        }

        imagens = dados.imagens;
        criarCartas();
        atualizarStatus();

    } catch (erro) {
        console.error("Erro ao carregar as cartas:", erro);

        tabuleiro.innerHTML = `
            <p class="erro">
                Não foi possível carregar as cartas.
            </p>
        `;
    }
}

// Embaralhar cartas
function embaralhar(array) {
    const copia = [...array];

    for (let i = copia.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));

        [copia[i], copia[j]] = [copia[j], copia[i]];
    }

    return copia;
}

// Criar cartas
function criarCartas() {
    tabuleiro.innerHTML = "";

    const cartas = embaralhar([...imagens, ...imagens]);
    const fragmento = document.createDocumentFragment();

    cartas.forEach((imagem, indice) => {
        const carta = document.createElement("div");

        carta.className = "carta";
        carta.dataset.imagem = imagem;
        carta.dataset.id = indice;

        carta.innerHTML = `
            <div class="carta-conteudo">
                <div class="carta-verso">?</div>

                <div class="carta-frente">
                    <img src="${imagem}" alt="Imagem da carta">
                </div>
            </div>
        `;

        carta.addEventListener("click", () => virarCarta(carta));

        fragmento.appendChild(carta);
    });

    tabuleiro.appendChild(fragmento);
}

// Virar carta
function virarCarta(carta) {
    if (
        bloqueado ||
        carta === primeiraCarta ||
        carta.classList.contains("encontrada")
    ) {
        return;
    }

    if (!jogoComecou) {
        jogoComecou = true;
        iniciarCronometro();
    }

    carta.classList.add("virada");

    if (primeiraCarta === null) {
        primeiraCarta = carta;
        return;
    }

    segundaCarta = carta;

    tentativas++;
    atualizarStatus();

    bloqueado = true;

    verificarPar();
}

// Verificar par
function verificarPar() {
    const saoIguais =
        primeiraCarta.dataset.imagem === segundaCarta.dataset.imagem;

    if (saoIguais) {
        setTimeout(() => {
            primeiraCarta.classList.add("encontrada");
            segundaCarta.classList.add("encontrada");

            pontos += 100;
            paresEncontrados++;

            atualizarStatus();
            limparSelecao();

            if (paresEncontrados === imagens.length) {
                finalizarJogo();
            }
        }, 500);

    } else {
        setTimeout(() => {
            primeiraCarta.classList.remove("virada");
            segundaCarta.classList.remove("virada");

            limparSelecao();
        }, 1000);
    }
}

// Limpar seleção
function limparSelecao() {
    primeiraCarta = null;
    segundaCarta = null;
    bloqueado = false;
}

// Iniciar cronômetro
function iniciarCronometro() {
    pararCronometro();

    cronometro = setInterval(() => {
        segundos++;
        atualizarTempo();
    }, 1000);
}

// Parar cronômetro
function pararCronometro() {
    if (cronometro !== null) {
        clearInterval(cronometro);
        cronometro = null;
    }
}

// Formatar tempo
function formatarTempo(valor) {
    const minutos = Math.floor(valor / 60);
    const segundosRestantes = valor % 60;

    return (
        String(minutos).padStart(2, "0") +
        ":" +
        String(segundosRestantes).padStart(2, "0")
    );
}

// Atualizar tempo
function atualizarTempo() {
    tempoElemento.textContent = formatarTempo(segundos);
}

// Atualizar status
function atualizarStatus() {
    pontosElemento.textContent = String(pontos).padStart(3, "0");
    tentativasElemento.textContent = String(tentativas).padStart(2, "0");

    atualizarTempo();
}

// Finalizar jogo
function finalizarJogo() {
    pararCronometro();

    setTimeout(() => {
        resultadoPontos.textContent = String(pontos).padStart(3, "0");
        resultadoTentativas.textContent = String(tentativas).padStart(2, "0");
        resultadoTempo.textContent = formatarTempo(segundos);

        mensagem.classList.add("ativa");

        mensagem.setAttribute("aria-hidden", "false");
    }, 700);
}

// Reiniciar jogo
function reiniciarJogo() {
    pararCronometro();

    primeiraCarta = null;
    segundaCarta = null;
    bloqueado = false;
    paresEncontrados = 0;
    pontos = 0;
    tentativas = 0;
    segundos = 0;
    jogoComecou = false;

    mensagem.classList.remove("ativa");

    mensagem.setAttribute("aria-hidden", "true");

    atualizarStatus();
    criarCartas();
}

// Botões
botaoReiniciar.addEventListener("click", reiniciarJogo);

jogarNovamente.addEventListener("click", reiniciarJogo);

// Iniciar jogo
carregarCartas();